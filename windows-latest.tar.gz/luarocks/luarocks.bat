@ECHO OFF
SETLOCAL ENABLEDELAYEDEXPANSION ENABLEEXTENSIONS
call "C:\Program Files\Microsoft Visual Studio\2022\Enterprise\VC\Auxiliary\Build\vcvarsall.bat" x64 > NUL
SET "LUA_PATH=D:\a\hererocks\hererocks\win64-7e0e79adbb9d2287485c7549a8adc3ca04711a55\luarocks\lua\?.lua;D:\a\hererocks\hererocks\win64-7e0e79adbb9d2287485c7549a8adc3ca04711a55\luarocks\lua\?\init.lua;%LUA_PATH%"
IF NOT "%LUA_PATH_5_2%"=="" (
   SET "LUA_PATH_5_2=D:\a\hererocks\hererocks\win64-7e0e79adbb9d2287485c7549a8adc3ca04711a55\luarocks\lua\?.lua;D:\a\hererocks\hererocks\win64-7e0e79adbb9d2287485c7549a8adc3ca04711a55\luarocks\lua\?\init.lua;%LUA_PATH_5_2%"
)
IF NOT "%LUA_PATH_5_3%"=="" (
   SET "LUA_PATH_5_3=D:\a\hererocks\hererocks\win64-7e0e79adbb9d2287485c7549a8adc3ca04711a55\luarocks\lua\?.lua;D:\a\hererocks\hererocks\win64-7e0e79adbb9d2287485c7549a8adc3ca04711a55\luarocks\lua\?\init.lua;%LUA_PATH_5_3%"
)
SET "PATH=D:\a\hererocks\hererocks\win64-7e0e79adbb9d2287485c7549a8adc3ca04711a55\luarocks;%PATH%"
"D:\a\hererocks\hererocks\win64-7e0e79adbb9d2287485c7549a8adc3ca04711a55\bin\lua.exe" "D:\a\hererocks\hererocks\win64-7e0e79adbb9d2287485c7549a8adc3ca04711a55\luarocks\luarocks.lua" %*
SET EXITCODE=%ERRORLEVEL%
IF NOT "%EXITCODE%"=="2" GOTO EXITLR

REM Permission denied error, try and auto elevate...
REM already an admin? (checking to prevent loops)
NET SESSION >NUL 2>&1
IF "%ERRORLEVEL%"=="0" GOTO EXITLR

REM Do we have PowerShell available?
PowerShell /? >NUL 2>&1
IF NOT "%ERRORLEVEL%"=="0" GOTO EXITLR

:GETTEMPNAME
SET TMPFILE=%TEMP%\LuaRocks-Elevator-%RANDOM%.bat
IF EXIST "%TMPFILE%" GOTO :GETTEMPNAME 

ECHO @ECHO OFF                                  >  "%TMPFILE%"
ECHO CHDIR /D %CD%                              >> "%TMPFILE%"
ECHO ECHO %0 %*                                 >> "%TMPFILE%"
ECHO ECHO.                                      >> "%TMPFILE%"
ECHO CALL %0 %*                                 >> "%TMPFILE%"
ECHO ECHO.                                      >> "%TMPFILE%"
ECHO ECHO Press any key to close this window... >> "%TMPFILE%"
ECHO PAUSE ^> NUL                               >> "%TMPFILE%"
ECHO DEL "%TMPFILE%"                            >> "%TMPFILE%"

ECHO Now retrying as a privileged user...
PowerShell -Command (New-Object -com 'Shell.Application').ShellExecute('%TMPFILE%', '', '', 'runas')

:EXITLR
exit /b %EXITCODE% 
