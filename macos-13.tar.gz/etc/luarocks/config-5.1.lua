-- LuaRocks configuration

rocks_trees = {
   { name = "user", root = home .. "/.luarocks" };
   { name = "system", root = "/Users/runner/work/hererocks/hererocks/macos-7e0e79adbb9d2287485c7549a8adc3ca04711a55" };
}
variables = {
   LUA_DIR = "/Users/runner/work/hererocks/hererocks/macos-7e0e79adbb9d2287485c7549a8adc3ca04711a55";
   LUA_BINDIR = "/Users/runner/work/hererocks/hererocks/macos-7e0e79adbb9d2287485c7549a8adc3ca04711a55/bin";
   LUA_VERSION = "5.1";
   LUA = "/Users/runner/work/hererocks/hererocks/macos-7e0e79adbb9d2287485c7549a8adc3ca04711a55/bin/lua";
}
