-- LuaRocks configuration

rocks_trees = {
   { name = "user", root = home .. "/.luarocks" };
   { name = "system", root = "/home/runner/work/hererocks/hererocks/ubuntu-7e0e79adbb9d2287485c7549a8adc3ca04711a55" };
}
variables = {
   LUA_DIR = "/home/runner/work/hererocks/hererocks/ubuntu-7e0e79adbb9d2287485c7549a8adc3ca04711a55";
   LUA_BINDIR = "/home/runner/work/hererocks/hererocks/ubuntu-7e0e79adbb9d2287485c7549a8adc3ca04711a55/bin";
   LUA_VERSION = "5.1";
   LUA = "/home/runner/work/hererocks/hererocks/ubuntu-7e0e79adbb9d2287485c7549a8adc3ca04711a55/bin/lua";
}
