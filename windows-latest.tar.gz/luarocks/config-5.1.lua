rocks_trees = {
    { name = [[user]],
         root    = home..[[/luarocks]],
    },
    { name = [[system]],
         root    = [[d:\a\hererocks\hererocks\win64-7e0e79adbb9d2287485c7549a8adc3ca04711a55\]],
    },
}
variables = {
    MSVCRT = 'VCRUNTIME140',
}
verbose = false   -- set to 'true' to enable verbose output
fs_use_modules = false   -- prevent LuaRocks itself from using installed modules and blocking their files from removal 

cmake_generator = "Visual Studio 14 2015"
