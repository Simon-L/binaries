return {
   LUA_DIR=[[D:\a\hererocks\hererocks\win64-7e0e79adbb9d2287485c7549a8adc3ca04711a55]],
   LUA_INCDIR=[[D:\a\hererocks\hererocks\win64-7e0e79adbb9d2287485c7549a8adc3ca04711a55\include]],
   LUA_LIBDIR=[[D:\a\hererocks\hererocks\win64-7e0e79adbb9d2287485c7549a8adc3ca04711a55\lib]],
   LUA_BINDIR=[[D:\a\hererocks\hererocks\win64-7e0e79adbb9d2287485c7549a8adc3ca04711a55\bin]],
   LUA_VERSION=[[5.1]],
   LUA=[[D:\a\hererocks\hererocks\win64-7e0e79adbb9d2287485c7549a8adc3ca04711a55\bin\lua.exe]],
   SYSTEM = [[windows]],
   PROCESSOR = [[x86_64]],
   PREFIX = [[D:\a\hererocks\hererocks\win64-7e0e79adbb9d2287485c7549a8adc3ca04711a55\luarocks]],
   SYSCONFDIR = [[D:\a\hererocks\hererocks\win64-7e0e79adbb9d2287485c7549a8adc3ca04711a55\luarocks]],
   WIN_TOOLS = [[D:\a\hererocks\hererocks\win64-7e0e79adbb9d2287485c7549a8adc3ca04711a55\luarocks/tools]],
}
